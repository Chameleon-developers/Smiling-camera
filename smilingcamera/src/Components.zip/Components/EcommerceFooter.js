import React from 'react';
import './EcommerceFooter.css';

class ShowEcommerceFooter extends React.Component {
    render(){
        return <div id="ShowEcommerceFooter">
            <div id="ShowEcommerceContactInfo">
                Seccion de Contacto
                fsfs
                sffs
            </div>
            <div id="ShowEcommerceRights">
                Todos los derechos reservados
            </div>
            
        </div>
    }
}

export default ShowEcommerceFooter;