import React from 'react'
import Adminmenu from './AdminMenu.js'

class DashboardAdmin extends React.Component{
    render(){
        return <div>
            <Adminmenu></Adminmenu>
        </div>
    }
}

export default DashboardAdmin;